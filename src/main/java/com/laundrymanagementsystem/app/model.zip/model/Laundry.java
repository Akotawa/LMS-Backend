package com.laundrymanagementsystem.app.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.CreatedDate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.laundrymanagementsystem.app.config.CustomDateAndTimeDeserialize;
import com.laundrymanagementsystem.app.config.CustomJsonDateSerializer;
import com.laundrymanagementsystem.app.constants.Constants;

@Entity
@Table(name = Constants.LAUNDRY_TABLE_NAME)
@JsonIgnoreProperties
public class Laundry {
	public static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(nullable = true)
	@Temporal(TemporalType.TIMESTAMP)
	@CreatedDate
	@JsonSerialize(using = CustomJsonDateSerializer.class)
	@JsonDeserialize(using = CustomDateAndTimeDeserialize.class)
	private Date createdAt;

	@Column(nullable = true)
	@Temporal(TemporalType.TIMESTAMP)
	@CreatedDate
	@JsonSerialize(using = CustomJsonDateSerializer.class)
	@JsonDeserialize(using = CustomDateAndTimeDeserialize.class)
	private Date updatedAt;

	private String laundryName;
	private String laundryType;
	private int nuumberOfmachine;
	private String mobileNumber;
	private Boolean active = Boolean.TRUE;
	private Integer status = 0;
	private Integer orderstatus = 0;
	private Integer adminId;
	public Integer getAdminId() {
		return adminId;
	}

	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}

	public Integer getOrderstatus() {
		return orderstatus;
	}

	public void setOrderstatus(Integer orderstatus) {
		this.orderstatus = orderstatus;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getLaundryName() {
		return laundryName;
	}

	public void setLaundryName(String laundryName) {
		this.laundryName = laundryName;
	}

	public String getLaundryType() {
		return laundryType;
	}

	public void setLaundryType(String laundryType) {
		this.laundryType = laundryType;
	}

	public int getNuumberOfmachine() {
		return nuumberOfmachine;
	}

	public void setNuumberOfmachine(int nuumberOfmachine) {
		this.nuumberOfmachine = nuumberOfmachine;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
